import { MarketIndex, ChartDataPoint } from '../types/market';

export const mockNifty50: MarketIndex = {
  symbol: 'NIFTY 50',
  name: 'National Stock Exchange of India',
  value: 22217.45,
  change: 145.65,
  changePercent: 0.66,
  previousClose: 22071.80,
  dayHigh: 22249.40,
  dayLow: 22124.35,
  timestamp: new Date().toISOString(),
};

export const mockSensex: MarketIndex = {
  symbol: 'SENSEX',
  name: 'Bombay Stock Exchange',
  value: 73158.24,
  change: 423.95,
  changePercent: 0.58,
  previousClose: 72734.29,
  dayHigh: 73256.82,
  dayLow: 72832.51,
  timestamp: new Date().toISOString(),
};

export function generateMockChartData(days: number, baseValue: number): ChartDataPoint[] {
  return Array.from({ length: days }, (_, i) => {
    const date = new Date();
    date.setDate(date.getDate() - (days - i));
    
    return {
      time: date.toISOString().split('T')[0],
      value: baseValue + Math.random() * 1000 - 500,
    };
  });
}