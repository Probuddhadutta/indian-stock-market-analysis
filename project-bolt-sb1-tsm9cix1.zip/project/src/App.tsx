import React from 'react';
import { LineChart, Bell, Users } from 'lucide-react';
import { MarketOverview } from './components/market/MarketOverview';
import { mockNifty50, mockSensex, generateMockChartData } from './utils/mockData';

export default function App() {
  const niftyData = generateMockChartData(100, 22000);
  const sensexData = generateMockChartData(100, 73000);

  return (
    <div className="min-h-screen bg-gray-100">
      <nav className="bg-white shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <LineChart className="w-8 h-8 text-blue-600" />
              <span className="ml-2 text-xl font-bold">Indian Markets</span>
            </div>
            <div className="flex items-center space-x-4">
              <Bell className="w-6 h-6 text-gray-600" />
              <Users className="w-6 h-6 text-gray-600" />
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <MarketOverview
          nifty50={mockNifty50}
          sensex={mockSensex}
          niftyData={niftyData}
          sensexData={sensexData}
        />
      </main>
    </div>
  );
}