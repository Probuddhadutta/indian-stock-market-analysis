import React from 'react';
import { Wallet, PieChart } from 'lucide-react';
import type { Portfolio } from '../types/stock';

interface PortfolioSummaryProps {
  portfolio: Portfolio;
}

export function PortfolioSummary({ portfolio }: PortfolioSummaryProps) {
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Wallet className="w-6 h-6 text-blue-600" />
          <h2 className="text-xl font-semibold">{portfolio.name}</h2>
        </div>
        <PieChart className="w-6 h-6 text-gray-400" />
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <div>
          <p className="text-sm text-gray-600">Total Value</p>
          <p className="text-2xl font-bold">${portfolio.totalValue.toLocaleString()}</p>
        </div>
        <div>
          <p className="text-sm text-gray-600">Daily Change</p>
          <p className={`text-lg font-semibold ${
            portfolio.dailyChange >= 0 ? 'text-green-500' : 'text-red-500'
          }`}>
            {portfolio.dailyChange >= 0 ? '+' : ''}
            ${portfolio.dailyChange.toFixed(2)} ({portfolio.dailyChangePercent.toFixed(2)}%)
          </p>
        </div>
      </div>
      
      <div className="mt-6">
        <h3 className="text-sm font-medium text-gray-600 mb-2">Holdings</h3>
        <div className="space-y-2">
          {portfolio.holdings.map((holding) => (
            <div key={holding.symbol} className="flex justify-between items-center">
              <div>
                <p className="font-medium">{holding.symbol}</p>
                <p className="text-sm text-gray-600">{holding.shares} shares</p>
              </div>
              <div className="text-right">
                <p className="font-medium">${holding.totalValue.toLocaleString()}</p>
                <p className={`text-sm ${
                  holding.gain >= 0 ? 'text-green-500' : 'text-red-500'
                }`}>
                  {holding.gain >= 0 ? '+' : ''}
                  {holding.gainPercent.toFixed(2)}%
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}