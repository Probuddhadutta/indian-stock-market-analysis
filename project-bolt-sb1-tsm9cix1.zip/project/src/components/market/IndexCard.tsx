import React from 'react';
import { TrendingUp, TrendingDown } from 'lucide-react';
import type { MarketIndex } from '../../types/market';

interface IndexCardProps {
  index: MarketIndex;
  onClick?: () => void;
}

export function IndexCard({ index, onClick }: IndexCardProps) {
  const isPositive = index.change >= 0;

  return (
    <div
      onClick={onClick}
      className="bg-white rounded-lg shadow-md p-4 hover:shadow-lg transition-shadow cursor-pointer"
    >
      <div className="flex justify-between items-start">
        <div>
          <h3 className="text-lg font-semibold">{index.symbol}</h3>
          <p className="text-sm text-gray-600">{index.name}</p>
        </div>
        {isPositive ? (
          <TrendingUp className="text-green-500" />
        ) : (
          <TrendingDown className="text-red-500" />
        )}
      </div>
      <div className="mt-4">
        <p className="text-2xl font-bold">{index.value.toFixed(2)}</p>
        <div className={`flex items-center ${isPositive ? 'text-green-500' : 'text-red-500'}`}>
          <span className="text-sm">
            {isPositive ? '+' : ''}{index.change.toFixed(2)} ({index.changePercent.toFixed(2)}%)
          </span>
        </div>
      </div>
      <div className="mt-2 grid grid-cols-2 gap-2 text-sm text-gray-600">
        <div>
          <p>Day High</p>
          <p className="font-medium">{index.dayHigh.toFixed(2)}</p>
        </div>
        <div>
          <p>Day Low</p>
          <p className="font-medium">{index.dayLow.toFixed(2)}</p>
        </div>
      </div>
    </div>
  );
}