import React from 'react';
import { TrendingUp, TrendingDown } from 'lucide-react';
import type { Stock } from '../types/stock';

interface StockCardProps {
  stock: Stock;
  onClick?: () => void;
}

export function StockCard({ stock, onClick }: StockCardProps) {
  const isPositive = stock.change >= 0;

  return (
    <div
      onClick={onClick}
      className="bg-white rounded-lg shadow-md p-4 hover:shadow-lg transition-shadow cursor-pointer"
    >
      <div className="flex justify-between items-start">
        <div>
          <h3 className="text-lg font-semibold">{stock.symbol}</h3>
          <p className="text-sm text-gray-600">{stock.name}</p>
        </div>
        {isPositive ? (
          <TrendingUp className="text-green-500" />
        ) : (
          <TrendingDown className="text-red-500" />
        )}
      </div>
      <div className="mt-4">
        <p className="text-2xl font-bold">${stock.price.toFixed(2)}</p>
        <div className={`flex items-center ${isPositive ? 'text-green-500' : 'text-red-500'}`}>
          <span className="text-sm">
            {isPositive ? '+' : ''}{stock.change.toFixed(2)} ({stock.changePercent.toFixed(2)}%)
          </span>
        </div>
      </div>
      <div className="mt-2 grid grid-cols-2 gap-2 text-sm text-gray-600">
        <div>
          <p>Volume</p>
          <p className="font-medium">{stock.volume.toLocaleString()}</p>
        </div>
        <div>
          <p>Market Cap</p>
          <p className="font-medium">${(stock.marketCap / 1e9).toFixed(2)}B</p>
        </div>
      </div>
    </div>
  );
}